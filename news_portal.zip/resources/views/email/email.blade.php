<x-header/>
Send your mail successfuly
<x-footer/>