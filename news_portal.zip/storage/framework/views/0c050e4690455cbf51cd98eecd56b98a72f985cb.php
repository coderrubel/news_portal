
<?php $__env->startSection('admin'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card p-3">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-1" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <div class="table-responsive-sm table-responsive-md">
                <table id="example" class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">Name</th>
                            <th class="text-center">Division</th>
                            <th class="text-center">District</th>
                            <th class="text-center">Specialist</th>
                            <th class="text-center">Photo</th>
                            <th class="text-center">View</th>
                            <th scope="col" class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($row->name); ?></td>
                            <td class="text-center"><?php echo e($row->rDivision->division); ?></td>
                            <td class="text-center"><?php echo e($row->rDistrict->district); ?></td>
                            <td class="text-center"><?php echo e($row->specialist); ?></td>
                            <td class="text-center"><img src="<?php echo e(asset($row->photo)); ?>" style="height:40px; width:70px;"></td>
                            <td class="text-center"><?php echo e($row->view??''); ?></td>
                            <td class="text-right">
                                <div class="dropdown show d-inline-block widget-dropdown">
                                    <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('doctor/edit/'.$row->id)); ?>"><span class="btn btn-sm btn-info">Edit</span></a>
                                    </li>
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('doctor/delete/'.$row->id)); ?>"><span class="btn btn-sm btn-danger">Delete</span></a>
                                    </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/doctor/index.blade.php ENDPATH**/ ?>