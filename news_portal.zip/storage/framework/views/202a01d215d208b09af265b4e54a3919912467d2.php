
<?php $__env->startSection('admin'); ?>

<!-- Text editor -->
<script>
tinymce.init({
    selector: '#mytextarea'
});
</script>

    <div class="py-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card card-header">Edit Doctor</div>
                        <div class="card card-body">
                            <form action="<?php echo e(url('doctor/update/'.$doctor->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <!-- Name -->
                                    <label for="addcategory" class="form-label mb-0">Name</label>
                                    <?php $__errorArgs = ['Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="name" value="<?php echo e($doctor->name); ?>" class="form-control rounded" placeholder="Name">
                                    <!-- specialist -->
                                    <label for="post" class="form-label mt-2 mb-1">Doctor Specialist *</label>
                                    <?php $__errorArgs = ['specialist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="specialist" value="<?php echo e($doctor->specialist); ?>" class="form-control rounded mb-2" id="post" placeholder="Specialist">
                                    <!-- district -->
                                    <label for="post" class="form-label mt-2 mb-1">District *</label>
                                    <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="district" value="<?php echo e($doctor->district); ?>" class="form-control rounded mb-2" id="post" placeholder="District">
                                    <!-- chamber -->
                                    <label class="form-label mt-2 mb-1">Chamber and Appointment *</label>
                                    <?php $__errorArgs = ['chamber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <textarea name="chamber" id="mytextarea" class="form-control  mb-2" row="15"><?php echo e($doctor->chamber); ?></textarea>
                                    <!-- photo -->
                                    <label for="photo" class="form-label mt-2 mb-1">Doctor Photo *</label>
                                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="file" class="form-control-file form-control mb-2 p-2" id="photo" name="photo">
                                    <button type="submit" class="btn btn-primary mt-2">Update</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/doctor/edit.blade.php ENDPATH**/ ?>