
<?php $__env->startSection('admin'); ?>

        <!-- All Category Section -->
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                        <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between card-header"><span>All Sub Category</span> <span>Total Sub Catagory: <?php echo e(count($subcagagorys)); ?> </span></div>
                    <div class="table-responsive-sm table-responsive-md">
                        <table class="table">
                            <thead>
                                <tr>
                                <th scope="col">Category Name</th>
                                <th scope="col" class="text-center">Sub Category Name</th>
                                <th scope="col" class="text-center">Created At</th>
                                <th scope="col" class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $subcagagorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <th scope="row"><?php echo e($row->rCaregory->category_name); ?></th>
                                <td class="text-center"><?php echo e($row->sub_category_name); ?></td>
                                <td class="text-center"><?php echo e(date('d-M-Y', strtotime($row->created_at))); ?></td>
                                <td class="text-right">
                                <div class="dropdown show d-inline-block widget-dropdown">
                                    <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('/subcategory/edit/'.$row->id)); ?>">Edit</a>
                                    </li>
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('/softdelete/subcategory/'.$row->id)); ?>">Remove</a>
                                    </li>
                                    </ul>
                                </div>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Add Category -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card card-header">Add Category </div>
                    <div class="card card-body">
                        <form action="<?php echo e(route('store.subcategory')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="my-2">

                                <label for="addcategory" class="form-label d-block">Catagory Name</label>
                                <select name="category_id" class="form-control rounded mt-2">
                                    <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <label for="addcategory" class="form-label">Sub Category Name*</label>
                                <?php $__errorArgs = ['sub_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                <input type="text" name="sub_category_name" class="form-control rounded mb-2" id="addcategory" placeholder="Sub Category Name">
                                <button type="submit" class="btn btn-primary mt-2">Add Sub Category</button>
                            </div>
                        </form>  
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SoftDelete Section -->
        <div class="row justify-content-start mt-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card card-header">Trasht  Category</div>
                    <div class="table-responsive-sm table-responsive-md">
                        <table class="table">
                            <thead>
                                <tr>
                                <th scope="col">Category Name</th>
                                <th scope="col" class="text-center">Sub Category Name</th>
                                <th scope="col" class="text-center">Created At</th>
                                <th scope="col" class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $trachCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <th scope="row"><?php echo e($row->rCaregory->category_name); ?></th>    
                                <td class="text-center"><?php echo e($row->sub_category_name); ?></td>
                                <td class="text-center"><?php echo e(date('d-M-Y', strtotime($row->created_at))); ?></td>
                                <td class="text-right">
                                    <div class="dropdown show d-inline-block widget-dropdown">
                                        <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                        <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                        <li class="dropdown-item">
                                            <a href="<?php echo e(url('subcategory/restore/'.$row->id)); ?>">Restore</a>
                                        </li>
                                        <li class="dropdown-item">
                                            <a href="<?php echo e(url('subcategory/pdelete/'.$row->id)); ?>">Delete</a>
                                        </li>
                                        </ul>
                                    </div>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>    
                        <!-- <?php echo e($trachCat->appends(['trach' => $trachCat->currentPage()])->links()); ?> -->
                    <div class="text-center mb-2 px-5"><?php echo e($trachCat->links()); ?></div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/subcategory/allsubcatagory.blade.php ENDPATH**/ ?>