
<?php $__env->startSection('admin'); ?>
    
   
        <!-- All Category Section -->
            <div class="row justify-content-center">
                <div class="col-md-12">
                   <a href="<?php echo e(route('add.slider')); ?>" class="btn btn-md btn-primary mb-4">Add FAQ</a>
                    <div class="card">
                        <?php if(session('success')): ?>
                         <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            <strong><?php echo e(session('success')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <div class="card card-header">All FAQ</div>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%">SL</th>
                                    <th scope="col" style="width:20%">FAQ Title</th>
                                    <th scope="col" style="width:40%">Description</th>
                                    <th scope="col" style="width:20%">Image</th>
                                    <th scope="col" style="width:15%; text-align:right">Action</th>
                                </tr>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:5%"><?php echo e($i++); ?></td>
                                    <td style="width:20%"><?php echo e($slider->title); ?></td>
                                    <td style="width:40%"><?php echo e($slider->description); ?></td>
                                    <td style="width:20%"><img src="<?php echo e(asset($slider->image)); ?>" style="height:40px; width:70px;"></td>
                                    <td style="width:15%; text-align:right">
                                        <a href="<?php echo e(url('/slider/edit/'.$slider->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                        <a href="<?php echo e(url('/slider/delete/'.$slider->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete')">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Add Brand
                <div class="col-md-4">
                    <div class="card">
                        <div class="card card-header">Add Slider </div>
                        <div class="card card-body">
                            <form action="<?php echo e(route('store.brand')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <label for="addcategory" class="form-label">Slider Name</label>
                                    <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="brand_name" class="form-control rounded" id="addcategory" placeholder="Brand Name">
                                    <label for="addimg" class="form-label">Brand Image</label>
                                    <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="file" name="brand_image" class="form-control rounded" id="addimg">
                                    <button type="submit" class="btn btn-primary mt-2">Add Brand</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
                 -->
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>