<?php if(count($doctors)>=1): ?>


    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-2 col-md-4">
            <div class="category-page-post-item">
                <div class="photo">
                    <img src="<?php echo e(asset($row->photo)); ?>" alt="HealthCareBD24">
                </div>
                <div class="category d-flex justify-content-between">
                    <span class="badge bg-success"><?php echo e($row->rDistrict->district); ?></span> 
                    <span class="badge bg-success"><?php echo e($row->specialist); ?></span>
                </div>
                <h3 class="pt-1"><a href="<?php echo e(url('/doctor_details/'.$row->slug)); ?>"> <?php echo e($row->name); ?> </a></h3>
                <div class="date-user">
                    <div class="date">Updated Date
                        <?php if($row->updated_at == NULL): ?>
                            <?php echo e($row->created_at->diffForHumans()); ?>

                        <?php else: ?> 
                            <?php echo e($row->updated_at->diffForHumans()); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <?php echo e($doctors->links()); ?>

        </div>
<?php else: ?>
    <div class="col-md-12">
        <h4 class="text-center">No Record Found</h4>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/pages/newDoctor.blade.php ENDPATH**/ ?>