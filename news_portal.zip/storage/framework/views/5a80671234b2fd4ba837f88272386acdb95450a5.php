
<?php $__env->startSection('admin'); ?>
    
   
        <!-- All Category Section -->
            <div class="row justify-content-center">
                <div class="col-md-12">
                   <a href="<?php echo e(route('add.contact')); ?>" class="btn btn-md btn-primary mb-4">All Message</a>
                    <div class="card">
                        <?php if(session('success')): ?>
                         <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            <strong><?php echo e(session('success')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <div class="card card-header">About</div>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%;">SL</th>
                                    <th scope="col" style="width:15%;">Name</th>
                                    <th scope="col" style="width:10%;">Email</th>
                                    <th scope="col" style="width:20%;">Subject</th>
                                    <th scope="col" style="width:35%; text-align:center;">Message</th>
                                    <th scope="col" style="width:10%; text-align:center;">Date</th>
                                    <th scope="col" style="width:5%; text-align:right">Action</th>
                                </tr>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:5%;"><?php echo e($i++); ?></td>
                                    <td style="width:15%;"><?php echo e($mess->name); ?></td>
                                    <td style="width:10%;"><?php echo e($mess->email); ?></td>
                                    <td style="width:20%;"><?php echo e($mess->subject); ?></td>
                                    <td style="width:35%; text-align:center;"><?php echo e($mess->message); ?></td>
                                    <td style="width:10%; text-align:center;">
                                        <?php if($mess->created_at == NULL): ?>
                                            <span class="text-danger">No Date Set</span>
                                        <?php else: ?> 
                                            <?php echo e($mess->created_at->diffForHumans()); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td style="width:5%; text-align:right">
                                        <a href="<?php echo e(url('/contact/delete/'.$mess->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete')">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </thead>
                        </table>
                        <div class="d-flex justify-content-center text-center mb-2 px-5"><?php echo e($message->links()); ?></div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/contact/message.blade.php ENDPATH**/ ?>