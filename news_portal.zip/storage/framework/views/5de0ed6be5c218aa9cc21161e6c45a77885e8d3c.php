

<?php $__env->startSection('admin'); ?>

<!-- Text editor -->
<script>
tinymce.init({
    selector: '#mytextarea'
});
</script>
<?php
$auth = Auth::user()->id;
$rolls = DB::table('users')->select('users.type','users.id')->where('users.id', $auth)->first();
?>
    <!-- SoftDelete Section -->
    <div class="row justify-content-start mt-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card card-header">Remove Posts</div>
                <div class="table-responsive-sm table-responsive-md m-3">
                    <table id="example" class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Post ID</th>
                                <th class="text-center">Catagory</th>
                                <th class="text-center">Post Title</th>
                                <th class="text-center">Image</th>
                                <th class="text-center">Author</th>
                                <th class="text-center">Create At</th>
                                <th scope="col" class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trachPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($row->admin_id == $auth || $rolls->type == 'admin' || $rolls->type == 'mentor'): ?>
                            <tr>
                                <th scope="row"><?php echo e($row->id); ?></th>
                                <td class="text-center"><?php echo e($row->rCaregory->sub_category_name); ?></td>
                                <td class="text-center"><?php echo e($row->post_title); ?></td>
                                <td class="text-center"><img src="<?php echo e(asset($row->post_photo)); ?>" style="height:40px; width:70px;"></td>
                                <td class="text-center"><?php echo e($row->user_name); ?></td>
                                <td class="text-center">
                                <?php if($row->created_at == NULL): ?>
                                    <span class="text-danger">No Date Set</span>
                                <?php else: ?> 
                                    <?php echo e($row->created_at->diffForHumans()); ?>

                                <?php endif; ?>
                                </td>
                                <td class="text-right">
                                    <div class="dropdown show d-inline-block widget-dropdown">
                                        <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                        <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                        <li class="dropdown-item">
                                            <a href="<?php echo e(url('post/restore/'.$row->id)); ?>">Restore</a>
                                        </li>
                                        <li class="dropdown-item">
                                            <a href="<?php echo e(url('/post/pdelete/'.$row->id)); ?>">Delete</a>
                                        </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/post/trash.blade.php ENDPATH**/ ?>