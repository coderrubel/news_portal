
<?php $__env->startSection('admin'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <div class="card card-header">All Users - <?php echo e(count($users)); ?></div>
                <div class="table-responsive-sm table-responsive-md">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Serial</th>
                                <th scope="col" class="text-center">Name</th>
                                <th scope="col" class="text-center">Email</th>
                                <th scope="col" class="text-center">Roll</th>
                                <th scope="col" class="text-center">Action</th>
                            </tr>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i++); ?></td>
                                <td class="text-center"><?php echo e($user->name); ?></td>
                                <td class="text-center"><?php echo e($user->email); ?></td>
                                <td class="text-center"><?php if($user->type == 'admin'): ?> Admin <?php elseif($user->type == 'mentor'): ?> Mentor <?php else: ?> User <?php endif; ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('/user/edit/'.$user->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                    <a href="<?php echo e(url('/user/delete/'.$user->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete')">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/users/index.blade.php ENDPATH**/ ?>