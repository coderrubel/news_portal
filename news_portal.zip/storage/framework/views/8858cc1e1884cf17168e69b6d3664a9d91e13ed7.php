
<?php $__env->startSection('admin'); ?>
    
   
        <!-- All Category Section -->
            <div class="row justify-content-center">
                <div class="col-md-12">
                   <a href="<?php echo e(route('add.contact')); ?>" class="btn btn-md btn-primary mb-4">Add Contact</a>
                    <div class="card">
                        <?php if(session('success')): ?>
                         <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            <strong><?php echo e(session('success')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <div class="card card-header">About</div>
                        <table class="table table-responsive-sm table-responsive-md">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%">SL</th>
                                    <th scope="col" style="width:10%">Phone Number</th>
                                    <th scope="col" style="width:25%">Email</th>
                                    <th scope="col" style="width:35%; text-align:center">Address</th>
                                    <th scope="col" style="width:15%; text-align:center">Date</th>
                                    <th scope="col" style="width:10%; text-align:right">Action</th>
                                </tr>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:5%;"><?php echo e($i++); ?></td>
                                    <td style="width:10%;"><?php echo e($contact->phone); ?></td>
                                    <td style="width:25%;"><?php echo e($contact->email); ?></td>
                                    <td style="width:35%; text-align:center"><?php echo e($contact->address); ?></td>
                                    <td style="width:15%; text-align:center">
                                        <?php if($contact->created_at == NULL): ?>
                                            <span class="text-danger">No Date Set</span>
                                        <?php else: ?> 
                                            <?php echo e($contact->created_at->diffForHumans()); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td style="width:10%; text-align:right">
                                        <a href="<?php echo e(url('/contact/edit/'.$contact->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                        <a href="<?php echo e(url('/contact/delete/'.$contact->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete')">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>