
<?php $__env->startSection('admin'); ?>

    <div class="py-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card card-header">Edit User </div>
                        <div class="card card-body">
                            <form action="<?php echo e(url('user/update/'.$users->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    
                                    <label for="addcategory" class="form-label mt-2 mb-0">User Permission</label>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                                    <select name="type" class="form-control rounded mt-2" value="<?php echo e($users->type); ?>">
                                        <option value="user" <?php if($users->type == 'user'): ?> Selected <?php endif; ?> >User</option>
                                        <option value="mentor" <?php if($users->type == 'mentor'): ?> Selected <?php endif; ?> >Mentor</option>
                                        <option value="admin" <?php if($users->type == 'admin'): ?> Selected <?php endif; ?> >Admin</option>
                                    </select>

                                    <button type="submit" class="btn btn-primary mt-2">Update User Permission</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>