
<?php $__env->startSection('admin'); ?>

<!-- Text editor -->
<script>
tinymce.init({
    selector: '#mytextarea'
});
</script>

    <div class="py-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card card-header">Edit Post</div>
                        <div class="card card-body">
                            <form action="<?php echo e(url('post/update/'.$post->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <!-- Post Title -->
                                    <label for="addcategory" class="form-label mb-0">Post Title</label>
                                    <?php $__errorArgs = ['post_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="post_title" value="<?php echo e($post->post_title); ?>" class="form-control rounded" placeholder="Post Title">
                                    <!-- Catagory name -->
                                    <label for="addcategory" class="form-label d-block mt-2 mb-0">Catagory Name *</label>
                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                                    <select name="sub_category_id" class="form-control rounded" id="sub_category" onchange="getCategory()">
                                    <option>Select one</option>
                                    <?php $__currentLoopData = $subcagagorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->sub_category_name); ?> (<?php echo e($item->rCaregory->category_name); ?>)</option>
                                    <!-- <option value="<?php echo e($item->id); ?>" <?php if( $post->sub_category_id == $item->id): ?> Selected <?php endif; ?> > <?php echo e($item->sub_category_name); ?> (<?php echo e($item->rCaregory->category_name); ?>)</option> -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="category_id" name="category_id" value="">
                                    </select>  
                                    <!-- Post Status -->
                                    <?php
                                    $auth = Auth::user()->id;
                                    $rolls = DB::table('users')->select('users.type','users.id')->where('users.id', $auth)->first();
                                    ?>
                                    <?php if($rolls->type == 'admin' || $rolls->type == 'mentor'): ?>
                                    <label for="addcategory" class="form-label d-block mt-2 mb-0">Post Status</label>
                                    <select name="status" class="form-control rounded" >
                                     <option value="active" <?php if($post->status == 'active'): ?> selected <?php endif; ?>>Active</option>
                                     <option value="inactive" <?php if($post->status == 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                                    </select>
                                    <?php endif; ?>
                                    <!-- post image -->
                                    <label for="post_photo" class="form-label d-block mt-2 mb-0">Post Image</label>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="file" name="post_photo" class="form-control rounded mb-3" id="addimg">
                                    <input type="text" name="old_image" value="<?php echo e($post->post_photo); ?>" class="form-control rounded mb-3" hidden>
                                    <img src="<?php echo e(asset($post->post_photo)); ?>" style="width:400px; height:200px;" alt="post_image"><br>
                                    <!-- Post details -->
                                    <label for="addcategory" class="form-label mt-2 mb-0">Post Details</label>
                                    <?php $__errorArgs = ['post_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                                    <textarea name="post_detail" id="mytextarea" class="form-control mt-2 mb-0" row="10"><?php echo e($post->post_detail); ?></textarea>
                                    <button type="submit" class="btn btn-primary mt-2">Update Post</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/post/edit.blade.php ENDPATH**/ ?>