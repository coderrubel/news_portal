
<?php $__env->startSection('admin'); ?>

        <!-- All Distric Section -->
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                        <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between card-header"><span>All District</span> <span>Total District: <?php echo e(count($districts)); ?> </span></div>
                    <div class="table-responsive-sm table-responsive-md">
                        <table class="table">
                            <thead>
                                <tr>
                                <th scope="col">Division</th>
                                <th scope="col" class="text-center">District</th>
                                <th scope="col" class="text-center">Created At</th>
                                <th scope="col" class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <th scope="row"><?php echo e($row->rDivision->division); ?></th>
                                <td class="text-center"><?php echo e($row->district); ?></td>
                                <td class="text-center"><?php echo e(date('d-M-Y', strtotime($row->created_at))); ?></td>
                                <td class="text-right">
                                <div class="dropdown show d-inline-block widget-dropdown">
                                    <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('/district/edit/'.$row->id)); ?>">Edit</a>
                                    </li>
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('/district/delete/'.$row->id)); ?>" onclick="return confirm('Are you sure to delete')">Delete</a>
                                    </li>
                                    </ul>
                                </div>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Add District -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card card-header">Add District</div>
                    <div class="card card-body">
                        <form action="<?php echo e(route('store.district')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="my-2">

                                <label for="addcategory" class="form-label d-block">Division Name</label>
                                <select name="division_id" class="form-control rounded mt-2">
                                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->division); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <label for="addcategory" class="form-label">District Name*</label>
                                <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                <input type="text" name="district" class="form-control rounded mb-2" id="addcategory" placeholder="District Name">
                                <button type="submit" class="btn btn-primary mt-2">Add</button>
                            </div>
                        </form>  
                    </div>
                </div>
            </div>
        </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/district/index.blade.php ENDPATH**/ ?>