<div class="news">
    <div class="news-heading">
        <h2>Popular News</h2>
    </div>           

    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Recent News</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Popular News</button>
        </li>
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <?php $i=0 ?>
            <?php $__currentLoopData = $recent_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <?php if($i==0): ?> <?php continue; ?> <?php endif; ?>
            <?php if($i>4): ?>
            <?php break; ?>
            <?php endif; ?>
            <div class="news-item">
                <div class="left">
                    <img src="<?php echo e(asset ($post->post_photo??'')); ?>" alt="">
                </div>
                <div class="right">
                    <div class="category">
                        <span class="badge bg-success"><?php echo e($post->rCaregory->sub_category_name??''); ?></span>
                    </div>
                    <h2><a href="<?php echo e(url('/post_details/'.$post->id )); ?>"><?php echo e($post->post_title??''); ?></a></h2>
                    <div class="date-user">
                        <div class="user">
                            <a href=""><?php echo e($post->user_name??''); ?></a>
                        </div>
                        <div class="fas fa-eye" style="margin-right: 20px; margin-top: 3px; position: relative; padding-left: 12px;color: #898989; font-size: 12px;">
                            <?php echo e($post->visitors??'0'); ?>

                        </div>
                        <div class="date">
                            <a href=""><?php echo e(date('d-M-Y', strtotime($post->created_at))); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
            <?php $i=0 ?>
            <?php $__currentLoopData = $popular_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++ ?>
            <?php if($i==0): ?> <?php continue; ?> <?php endif; ?>
            <?php if($i>4): ?>
            <?php break; ?>
            <?php endif; ?>
            <div class="news-item">
                <div class="left">
                    <img src="<?php echo e(asset ($post->post_photo??'')); ?>" alt="">
                </div>
                <div class="right">
                    <div class="category">
                        <span class="badge bg-success"><?php echo e($post->rCaregory->sub_category_name??''); ?></span>
                    </div>
                    <h2><a href="<?php echo e(url('/post_details/'.$post->id )); ?>"><?php echo e($post->post_title??''); ?></a></h2>
                    <div class="date-user">
                        <div class="user">
                            <a href=""><?php echo e($post->user_name??''); ?></a>
                        </div>
                        <div class="fas fa-eye" style="margin-right: 20px; margin-top: 3px; position: relative; padding-left: 12px;color: #898989; font-size: 12px;">
                            <?php echo e($post->visitors??'0'); ?>

                        </div>
                        <div class="date">
                            <a href=""><?php echo e(date('d-M-Y', strtotime($post->created_at))); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/components/popularNews.blade.php ENDPATH**/ ?>