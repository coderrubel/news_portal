<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
    <div class="page-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="breadcrumb-container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <a href="<?php echo e(url('/doctor_list')); ?>">Doctor List / </a><?php echo e($doctorview->name??''); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="card mb-3">
                      <div class="row g-0">
                        <div class="col-md-2">
                          <img src="<?php echo e(asset($doctorview->photo)); ?>" class="img-fluid rounded-start" style="max-height:160px">
                        </div>
                        <div class="col-md-10">
                          <div class="card-body">
                            <h5 class="card-title"><?php echo $doctorview->name??''; ?></h5>
                            <p class="card-text"><?php echo $doctorview->specialist??''; ?></p>
                            <p class="card-text"><span class="badge bg-success"><?php echo $doctorview->district??''; ?></span></p>
                            <?php if($doctorview->updated_at == NULL): ?>
                            <p class="card-text"><small class="text-body-secondary">Last updated <?php echo e($doctorview->created_at->format('d M Y')??''); ?></small></p>
                            <?php else: ?>
                            <p class="card-text"><small class="text-body-secondary">Last updated <?php echo e($doctorview->updated_at->format('d M Y')??''); ?></small></p>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                      <div class="row g-0 border-top">
                          <div class="card-body">
                             <p class="card-text"><?php echo $doctorview->chamber??''; ?></p>
                          </div>
                      </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 sidebar-col">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sidebar','data' => []]); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>


       
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\news_portal\resources\views/pages/doctor_view.blade.php ENDPATH**/ ?>