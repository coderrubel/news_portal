<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('HTbeNKZ')) {
    $componentId = $_instance->getRenderedChildComponentId('HTbeNKZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('HTbeNKZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HTbeNKZ');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('HTbeNKZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\news_portal\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>