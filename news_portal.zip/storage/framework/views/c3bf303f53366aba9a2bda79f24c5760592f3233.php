<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
        <meta name="description" content="">
        <title>News Portal</title>        
		
        <link rel="icon" type="image/png" href="<?php echo e(asset ('fontend/uploads/favicon.png')); ?>">

        <!-- All CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/jquery-ui.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/magnific-popup.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/select2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/select2-bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/spacing.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/font_awesome_5_free.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontend/css/style.css')); ?>">
        <link href="https://fonts.googleapis.com/css2?family=Maven+Pro:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
        
    </head>
    <body>
        <div class="top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <ul>
                            <li class="today-text">Today: <?php echo e(date('d-M-Y')); ?> </li>
                            <li class="email-text">support@gmail.com</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="right">
                            <li class="menu"><a href="<?php echo e(url('/faq')); ?>">FAQ</a></li>
                            <li class="menu"><a href="<?php echo e(url('/about')); ?>">About</a></li>
                            <li class="menu"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                            <?php if(Auth::check()): ?>
                                <li class="menu"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                                <li class="menu"><a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                            <?php else: ?>
                            <li class="menu"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li class="menu"><a href="<?php echo e(route('register')); ?>">Sign Up</a></li>
                            <?php endif; ?>
                            <!-- 
                            <li>
                                <div class="language-switch">
                                    <select name="">
                                        <option value="">Bangla</option>
                                        <option value="">English</option>
                                    </select>
                                </div>
                            </li>
                            -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="heading-area">
            <div class="container">
                <div class="row">
                    <?php
                    $logos = DB::table('logos')->orderBy('id','DESC')->first();
                    ?>
                    <?php if(!empty($logos->image)): ?>
                    <div class="col-md-4 d-flex align-items-center">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset($logos->image ?? '')); ?>" alt="<?php echo e($logos->name??''); ?>">
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php
                    $header = DB::table('header_ads')->orderBy('id','DESC')->first();
                    ?>
                    <?php if(!empty($header->ads_image)): ?>
                    <div class="col-md-8">
                        <div class="ad-section-1">
                            <a href="<?php echo e($header->ads_url ??''); ?>" target="_blank"><img src="<?php echo e(asset($header->ads_image ?? '')); ?>" alt="<?php echo e($header->ads_name ?? ''); ?>"></a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="website-menu">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
                                    </li>
                                    <?php $__currentLoopData = $global_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/allpost/'.$item->category_name)); ?>"><?php echo e($item->category_name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/doctor_list')); ?>">SPECIALIST DOCTORS LIST</a>
                                    </li>
                                    <!-- 
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Sposrts
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <li><a class="dropdown-item" href="#">Football</a></li>
                                            <li><a class="dropdown-item" href="#">Cricket</a></li>
                                            <li><a class="dropdown-item" href="#">Baseball</a></li>
                                        </ul>
                                    </li>    
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Gallery
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <li><a class="dropdown-item" href="photo-gallery.html">Photo Gallery</a></li>
                                            <li><a class="dropdown-item" href="video-gallery.html">Video Gallery</a></li>
                                        </ul>
                                    </li>
                                    -->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>       
<?php /**PATH C:\xampp\htdocs\news_portal\resources\views/components/header.blade.php ENDPATH**/ ?>