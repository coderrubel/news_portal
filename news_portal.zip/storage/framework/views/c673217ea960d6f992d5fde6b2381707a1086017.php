
<?php $__env->startSection('admin'); ?>

    <div class="py-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card card-header">Edit Sub Category </div>
                        <div class="card card-body">
                            <form action="<?php echo e(url('subcategory/update/'.$subcagagorys->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <label for="addcategory" class="form-label d-block">Catagory Name</label>
                                    <select name="category_id" class="form-control rounded mt-2">
                                        <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>" <?php if( $subcagagorys->category_id == $row->id): ?> Selected <?php endif; ?> ><?php echo e($row->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>    
                                    <label for="addcategory" class="form-label mt-2 mb-0">Update Category Name</label>
                                    <?php $__errorArgs = ['sub_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="sub_category_name" value="<?php echo e($subcagagorys->sub_category_name); ?>" class="form-control rounded" id="addcategory" placeholder="Update Sub Category Name">
                                    <label for="addcategory" class="form-label mt-2 mb-0">Update Category Order</label>
                                    <?php $__errorArgs = ['sub_catagory_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                                    <input type="text" name="sub_catagory_order" value="<?php echo e($subcagagorys->sub_catagory_order); ?>" class="form-control rounded mt-2" id="order" placeholder="Sub Catagory Order">
                                    
                                    <label for="addcategory" class="form-label mt-2 mb-0">Show On Menu</label>
                                    <?php $__errorArgs = ['show_on_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                                    <select name="show_on_menu" class="form-control rounded mt-2" value="<?php echo e($subcagagorys->show_on_menu); ?>">
                                        <option value="Show" <?php if($subcagagorys->show_on_menu == 'Show'): ?> Selected <?php endif; ?> >Show</option>
                                        <option value="Hide" <?php if($subcagagorys->show_on_menu == 'Hide'): ?> Selected <?php endif; ?> >Hide</option>
                                    </select>
                                    <button type="submit" class="btn btn-primary mt-2">Update Sub Category</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/subcategory/edit.blade.php ENDPATH**/ ?>