
<?php $__env->startSection('admin'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <div class="card card-header">All Sidebar-1 Advertisement Size:500x266</div>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">SL No</th>
                        <th scope="col" class="text-center">Name</th>
                        <th scope="col" class="text-center">URL</th>
                        <th scope="col" class="text-center">Image</th>
                        <th scope="col" class="text-center">Created At</th>
                        <th scope="col" class="text-right">Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td class="text-center"><?php echo e($ad->ads_name); ?></td>
                        <td class="text-center"><?php echo e($ad->ads_url); ?></td>
                        <td class="text-center"><img src="<?php echo e(asset($ad->ads_image)); ?>" style="height:50px; width:150px;"></td>
                        <td class="text-center">
                            <?php if($ad->created_at == NULL): ?>
                            <span class="text-danger">No Date Set</span>
                            <?php else: ?> 
                                <?php echo e($ad->created_at->diffForHumans()); ?>

                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <div class="dropdown show d-inline-block widget-dropdown">
                                <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                <li class="dropdown-item">
                                    <a href="<?php echo e(url('/sidebar1/edit/'.$ad->id)); ?>">Edit</a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(url('/sidebar1/delete/'.$ad->id)); ?>">Delete</a>
                                </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
            </table>
        </div>
    </div>
    <!-- Add Ads -->
    <div class="col-md-4">
        <div class="card">
            <div class="card card-header">Add Sidebar-1 Advertisement</div>
            <div class="card card-body">
                <form action="<?php echo e(route('store.sidebar1')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Advertisement Name*</label>
                    <?php $__errorArgs = ['ads_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                    <input type="text" name="ads_name" class="form-control rounded" id="name" placeholder="Advertisement Name">
                    <label for="url" class="form-label mt-2">Advertisement URL</label>
                    <?php $__errorArgs = ['ads_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                    <input type="text" name="ads_url" class="form-control rounded" id="url" placeholder="Advertisement Link">
                    <label for="addimg" class="form-label mt-2">Advertisement Image*</label>
                    <?php $__errorArgs = ['ads_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="file" name="ads_image" class="form-control rounded" id="addimg">
                    <button type="submit" class="btn btn-primary mt-3">Add Advertisement</button>
                </form>  
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/sidebarads1/index.blade.php ENDPATH**/ ?>