
<?php $__env->startSection('admin'); ?>

    <div class="py-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card card-header">Update FAQ </div>
                        <div class="card card-body">
                            <form action="<?php echo e(url('slider/update/'.$sliders->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="old_image" value="<?php echo e($sliders->image); ?>">
                                <!-- Title -->
                                <div class="my-2">
                                    <label for="addcategory" class="form-label">Update Title</label>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="text" name="title" value="<?php echo e($sliders->title); ?>" class="form-control rounded" id="addcategory" placeholder="Update Title">
                                </div>
                                <!-- Description -->
                                <div class="my-2">
                                    <label for="addcategory" class="form-label">Update Description</label>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="description"><?php echo e($sliders->description); ?></textarea>
                                    
                                </div>
                                <!-- Brand Image -->
                                <div class="my-2">
                                    <label for="addcategory" class="form-label">Update FAQ Image</label>
                                    <?php $__errorArgs = ['brnad_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                    <input type="file" name="image" class="form-control rounded mb-3" id="addimg">
                                    <img src="<?php echo e(asset($sliders->image)); ?>" style="width:400px; height:200px;" alt="slider_image"><br>
                                    
                                    <button type="submit" class="btn btn-primary mt-2">Update FAQ</button>
                                </div>
                            </form>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>