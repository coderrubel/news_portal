

<?php $__env->startSection('admin'); ?>

<!-- Text editor -->
<script>
tinymce.init({
    selector: '#mytextarea'
});
</script>
<?php
$auth = Auth::user()->id;
$rolls = DB::table('users')->select('users.type','users.id')->where('users.id', $auth)->first();
?>
<!-- All Active Post Section -->
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card p-3">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <!-- <div class="d-flex justify-content-between card-header"><span>All Active Posts</span> <?php if($rolls->type == 'admin' || $rolls->type == 'mentor'): ?><span>Total Active Posts: <?php echo e(count($post)); ?></span><?php endif; ?></div> -->
            <div class="table-responsive-sm table-responsive-md">
                <table id="example" class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Serial</th>
                            <th class="text-center">Catagory</th>
                            <th class="text-center">Post Title</th>
                            <th class="text-center">Image</th>
                            <th class="text-center">Author</th>
                            <th class="text-center">Visitors</th>
                            <?php if($rolls->type == 'admin' || $rolls->type == 'mentor'): ?>
                            <th class="text-center">Status</th>
                            <?php endif; ?>
                            <th class="text-center">Create At</th>
                            <th scope="col" class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($row->admin_id == $auth || $rolls->type == 'admin' || $rolls->type == 'mentor'): ?>
                        <tr>
                            <th scope="row"><?php echo e($post->firstItem()+$loop->index); ?></th>
                            <td class="text-center"><?php echo e($row->rCaregory->sub_category_name); ?></td>
                            <td class="text-center"><?php echo e($row->post_title); ?></td>
                            <!-- <td><?php echo e($row->post_detail); ?></td> -->
                            <td class="text-center"><img src="<?php echo e(asset($row->post_photo)); ?>" style="height:40px; width:70px;"></td>
                            <td class="text-center"><?php echo e($row->user_name); ?></td>
                            <td class="text-center"><?php if($row->visitors == NULL): ?> 0 <?php else: ?> <?php echo e($row->visitors); ?> <?php endif; ?></td>
                            <?php if($rolls->type == 'admin' || $rolls->type == 'mentor'): ?>
                            <td class="text-center">
                                <div id="ss<?php echo e($row->id); ?>">
                                <?php if($row->status == 'inactive'): ?> 
                                <span class="btn btn-sm btn-danger" onclick="statusChange(<?php echo $row->id ?>,<?php echo '0' ?>)">Inactive</span>   
                                <?php elseif($row->status == 'active'): ?>
                                <span class="btn btn-sm btn-success" onclick="statusChange(<?php echo $row->id ?>,<?php echo '1' ?>)">Active</span>      
                                <?php endif; ?>
                                </div>
                            </td>
                            <?php endif; ?>
                            <td class="text-center">
                            <?php if($row->created_at == NULL): ?>
                                <span class="text-danger">No Date Set</span>
                            <?php else: ?> 
                                <?php echo e($row->created_at->diffForHumans()); ?>

                            <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <div class="dropdown show d-inline-block widget-dropdown">
                                    <a class="dropdown-toggle icon-burger-mini" href="" role="button" id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static"></a>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-recent-order1">
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('post/edit/'.$row->id)); ?>"><span class="btn btn-sm btn-info">Edit</span></a>
                                    </li>
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(url('softdelete/post/'.$row->id)); ?>"><span class="btn btn-sm btn-danger">Remove</span></a>
                                    </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/post/allpost.blade.php ENDPATH**/ ?>