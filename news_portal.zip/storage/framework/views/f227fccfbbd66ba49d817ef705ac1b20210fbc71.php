
<?php $__env->startSection('admin'); ?>
<script>
tinymce.init({
    selector: '#mytextarea'
});
</script>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card card-header">Add Doctor </div>
            <div class="card card-body">
                <form action="<?php echo e(route('add.doctor')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="my-2">
                        <!-- Name -->
                        <label for="post" class="form-label mt-2 mb-1">Doctor Name *</label>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                        <input type="text" name="name" class="form-control rounded mb-2" id="post" placeholder="Doctor Name">
                        <!-- division district specialist -->
                        <div class="row">
                            <div class="col-md-4">
                                <label for="addcategory" class="form-label d-block">Select Division</label>
                                <select name="division" class="form-control rounded mt-2" id="divis" onchange="getDivis();">
                                    <option>Select Division</option>
                                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->division); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="addcategory" class="form-label d-block">Select Division</label>
                                <select name="district" class="form-control rounded mt-2" id="distri">
                              
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="addcategory" class="form-label d-block">Select Division</label>
                                <select name="specialist" class="form-control rounded mt-2">
                                    <?php $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->spec); ?>"><?php echo e($row->spec); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>    
                        </div>
                        <!-- district -->
                       
                        <!-- chamber -->
                        <label class="form-label mt-2 mb-1">Chamber and Appointment *</label>
                        <?php $__errorArgs = ['chamber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                        <textarea name="chamber" id="mytextarea" class="form-control  mb-2" row="15"></textarea>
                        <!-- photo -->
                        <label for="photo" class="form-label mt-2 mb-1">Doctor Photo *</label>
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                        <input type="file" class="form-control-file form-control mb-2 p-2" id="photo" name="photo">
                        <button type="submit" class="btn btn-primary mt-2">Add Doctor</button>
                    </div>
                </form>  
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_portal\resources\views/admin/doctor/add.blade.php ENDPATH**/ ?>